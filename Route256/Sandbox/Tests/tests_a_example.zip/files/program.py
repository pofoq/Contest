test_case_count = int(input())
for _ in range(test_case_count):
    a, b = map(int, input().split())
    print(a + b)
